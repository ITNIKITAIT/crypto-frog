// export const BASE_URL = "http://localhost:8080";
// export const BASE_URL = "http://85.208.51.218:8080";
export const BASE_URL = "https://backend.cryptofrog.shop";
