export type NotificationProps = {
  message: string;
  type: "success" | "error" | "info" | "warning";
};
