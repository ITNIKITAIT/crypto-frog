import { Box } from "@mui/material";

const Thumbnail = (): JSX.Element => <Box height={350} />;

Thumbnail.displayName = "Thumbnail";

export default Thumbnail;
