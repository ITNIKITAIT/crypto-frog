import { Delete } from "@mui/icons-material";
import { IconButton } from "@mui/material";
import { useAuth } from "lib/auth/admin/AuthContext";
import { useCallback, useState } from "react";
import DeleteCategoryModal from "./__DeleteCategoryModal";

const DeleteCategory = ({
  categoryId,
  categoryName,
  reload,
}: {
  categoryId: number;
  categoryName: string;
  reload: () => void;
}): JSX.Element => {
  const { token } = useAuth();

  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleModalOpen = useCallback(() => setIsModalOpen(true), []);
  const handleModalClose = useCallback(() => setIsModalOpen(false), []);

  return (
    <>
      <IconButton onClick={handleModalOpen}>
        <Delete />
      </IconButton>
      <DeleteCategoryModal
        categoryId={categoryId}
        categoryName={categoryName}
        token={token}
        isModalOpen={isModalOpen}
        onClose={handleModalClose}
        onSuccess={reload}
      />
    </>
  );
};

DeleteCategory.displayName = "DeleteCategory";

export default DeleteCategory;
