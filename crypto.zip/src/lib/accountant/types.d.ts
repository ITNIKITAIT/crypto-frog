export type AccountantItemProps = {
  itemId: number;
  itemName: string;
  quantity: number;
  income: number;
  sell: number;
};
