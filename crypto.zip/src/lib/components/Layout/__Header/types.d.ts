export type HeaderNavItem = {
  uuid: string;
  label: string;
  link: string;
};
