export const HEADER_NAV_ITEMS = [
  {
    uuid: "1",
    label: "contacts",
    link: "/contacts",
  },
  {
    uuid: "2",
    label: "replacementrules",
    link: "/replacement-rules",
  },
  // {
  //   uuid: "3",
  //   label: "Чекер аккаунтов",
  //   link: "/account-checker",
  // },
  // {
  //   uuid: "4",
  //   label: "uniquizer",
  //   link: "/uniquizer",
  // },
];
